package com.rabo.assignment.pojo;

public class RaboResponse {
	private String refernce;
	private String endBalance;
	private String description;
	
	public String getRefernce() {
		return refernce;
	}
	public void setRefernce(String refernce) {
		this.refernce = refernce;
	}
	public String getEndBalance() {
		return endBalance;
	}
	public void setEndBalance(String endBalance) {
		this.endBalance = endBalance;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
